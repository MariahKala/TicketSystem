﻿


namespace TicketingSystem.Models
{
    public class SprintNumber
    {
        public string SprintNumberId { get; set; } = string.Empty;
        public int Number { get; set; }
    }
}
