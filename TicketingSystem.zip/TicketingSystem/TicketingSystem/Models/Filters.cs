﻿namespace TicketingSystem.Models
{
    public class Filters
    {
        public Filters(string filterstring)
        {
            FilterString = filterstring ?? "all-all-all";
            string[] filters = FilterString.Split('-');
            SprintNumberId = filters[0];
            StatusId = filters[1];
        }

        //I haven't successfully incormporated this yet.
        public string FilterString { get; }
        public string SprintNumberId { get; }
        
        public string StatusId { get; }
        public bool HasSprintNumber => SprintNumberId.ToLower() != "all";
        
        public bool HasStatus => StatusId.ToLower() != "all";
        
    };

}



