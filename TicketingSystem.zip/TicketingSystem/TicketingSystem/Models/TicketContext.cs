﻿using Microsoft.EntityFrameworkCore;

namespace TicketingSystem.Models
{
        public class TicketContext : DbContext
        {
            public TicketContext(DbContextOptions<TicketContext> options)
                : base(options)
            { }

        public DbSet<Ticket> Tickets { get; set; } = null!;
        public DbSet<SprintNumber> SprintNumbers { get; set; } = null!;
        public DbSet<Status> Statuses { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SprintNumber>().HasData(
                new SprintNumber { SprintNumberId = "one", Number = 1 },
                new SprintNumber { SprintNumberId = "two", Number = 2 },
                new SprintNumber { SprintNumberId = "three", Number = 3 },
                new SprintNumber { SprintNumberId = "four", Number = 4 },
                new SprintNumber { SprintNumberId = "five", Number = 5 }
            );

            //(to do, in progress, quality assurance(qa), and done).
            modelBuilder.Entity<Status>().HasData(
                new Status { StatusId = "todo", StatusName = "To Do" },
                new Status { StatusId = "inprogress", StatusName = "In Progress" },
                new Status { StatusId = "qa", StatusName = "Quality Assurance" },
                new Status { StatusId = "done", StatusName = "Done" }
            );
        }

    }

    }


