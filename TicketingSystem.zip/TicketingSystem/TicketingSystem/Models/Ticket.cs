﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using TicketingSystem.Models;



namespace TicketingSystem.Models
{
    public class Ticket
    {
        //Asignment variables: Ticket, with name, description, sprint number, point value, and status (to do, in progress, quality assurance(qa), and done).
        public int TicketId { get; set; }

        [Required(ErrorMessage = "Please enter the name.")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a description.")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the point value.")]
        public string PointValue { get; set; } = string.Empty;

        public string SprintNumberId { get; set; } = null!;
        [ValidateNever]
        public SprintNumber SprintNumber { get; set; } = null!;
        public string StatusId { get; set; } = string.Empty; 
        [ValidateNever]

        public Status Status { get; set; } = null!;



    }
}
