﻿namespace TicketingSystem.Models
{
    public class Status
    {
        //to do, in progress, quality assurance, and done
        public string StatusId { get; set; } = string.Empty;
        public string StatusName { get; set; } = string.Empty;
    }
}
