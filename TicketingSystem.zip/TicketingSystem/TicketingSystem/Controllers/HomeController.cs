﻿using Microsoft.AspNetCore.Mvc;
using TicketingSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace TicketingSystem.Controllers
{
    public class HomeController : Controller
    {
        private TicketContext context;
        public HomeController(TicketContext ctx) => context = ctx;

        public ViewResult Index(string id)
        {
            var tickets = context.Tickets
                .Include(s => s.Status)
                .Include(s => s.SprintNumber)
                .OrderBy(s => s.Name)
                .ToList();

            return View(tickets);
        }


    }
}