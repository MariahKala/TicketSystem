﻿using Microsoft.AspNetCore.Mvc;
using TicketingSystem.Models;

namespace TicketingSystem.Controllers
{
    public class TicketController : Controller
    {
        private TicketContext context { get; set; }

        public TicketController(TicketContext ctx) => context = ctx;

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Statuses = context.Statuses.OrderBy(s => s.StatusId).ToList();
            ViewBag.SprintNumbers = context.SprintNumbers.OrderBy(s => s.Number).ToList();
            return View("Edit", new Ticket());
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Statuses = context.Statuses.OrderBy(s => s.StatusName).ToList();
            ViewBag.SprintNumbers = context.SprintNumbers.OrderBy(s => s.Number).ToList();
            var ticket = context.Statuses.Find(id);
            return View(ticket);
        }

        [HttpPost]
        public IActionResult Edit(Ticket ticket)
        {
            if (ModelState.IsValid)
            {
                if (ticket.TicketId == 0)
                    context.Tickets.Add(ticket);
                else
                    context.Tickets.Update(ticket);
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Action = (ticket.TicketId == 0) ? "Add" : "Edit";
                ViewBag.Statuses = context.Statuses.OrderBy(s => s.StatusName).ToList();
                ViewBag.SprintNumbers = context.SprintNumbers.OrderBy(s => s.Number).ToList();
                return View(ticket);
            }
        }

        public IActionResult MarkComplete([FromRoute] string id, Ticket selected)
        {
            selected = context.Tickets.Find(selected.TicketId)!;  // use null-forgiving operator to suppress null warning
            if (selected != null)
            {
                selected.StatusId = "done";
                context.SaveChanges();
            }

            return RedirectToAction("Index", new { ID = id });
        }

        [HttpPost]
        public IActionResult DeleteDone(string id)
        {
            var toDelete = context.Tickets
                .Where(t => t.StatusId == "done").ToList();

            foreach (var ticket in toDelete)
            {
                context.Tickets.Remove(ticket);
            }
            context.SaveChanges();

            return RedirectToAction("Index", new { ID = id });
        }

    }
}
